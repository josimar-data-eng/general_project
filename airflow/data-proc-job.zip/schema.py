flight_nums_schema =[
                    ('avg_departure_delay' , 'FLOAT'   , 'REQUIRED')
                    ,('avg_arrival_delay'   , 'FLOAT'   , 'REQUIRED')
                    ,('flight_num'          , 'INTEGER' , 'REQUIRED')
                    ,('flight_date'         , 'DATE'    , 'REQUIRED')
                    ]